# EpiClass


##### readthedocs.com documentation:

https://epiclass.readthedocs.io/en/latest/index.html


##### check out the preprint for more information:

https://doi.org/10.1101/579839


##### For a deeper look into the code and generating the figures in the manuscript, check out the vignette:

```manuscript_figures/vignette/README_vignette.ipynb```

# EpiClass

information located at:
docs/source/index.rst.

readthedocs page coming soon...


## Tests
	### Install
	
	pytest and nose packages
	
	
	### Run
	
	$ py.test
